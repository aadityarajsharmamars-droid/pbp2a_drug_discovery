import tkinter as tk
from tkinter import messagebox
import numpy as np
import joblib

from rdkit import Chem
from rdkit.Chem import AllChem

# ----------------------------
# LOAD MODELS
# ----------------------------
model_xgb = joblib.load("models/pbp2a_qsar_model_optimized_xgb_enriched_cleaned.pkl")
model_stack = joblib.load("models/pbp2a_qsar_model_stacking_enriched_cleaned.pkl")
model_base = joblib.load("models/pbp2a_qsar_model.pkl")

# ----------------------------
# MORGAN FINGERPRINT FUNCTION
# ----------------------------
def smiles_to_morgan(smiles):
    mol = Chem.MolFromSmiles(smiles)
    if mol is None:
        return None

    # ⚠️ CHANGE THESE TO MATCH TRAINING
    radius = 2
    nBits = 2048

    fp = AllChem.GetMorganFingerprintAsBitVect(
        mol,
        radius,
        nBits=nBits
    )

    arr = np.array(fp)
    return arr.reshape(1, -1)


# ----------------------------
# PREDICTION FUNCTION
# ----------------------------
def predict():
    smiles = entry.get().strip()

    X = smiles_to_morgan(smiles)

    if X is None:
        messagebox.showerror("Error", "Invalid SMILES")
        return

    try:
        pred_xgb = model_xgb.predict(X)[0]
        pred_stack = model_stack.predict(X)[0]
        pred_base = model_base.predict(X)[0]

        result = f"""
XGBoost Model: {pred_xgb:.4f}
Stacking Model: {pred_stack:.4f}
Base Model: {pred_base:.4f}
"""

        messagebox.showinfo("IC50 Prediction", result)

    except Exception as e:
        messagebox.showerror("Error", str(e))


# ----------------------------
# GUI
# ----------------------------
root = tk.Tk()
root.title("PBP2a IC50 Predictor")

tk.Label(root, text="Enter SMILES:", font=("Arial", 12)).pack(pady=10)

entry = tk.Entry(root, width=50)
entry.pack(pady=5)

tk.Button(root, text="Predict IC50", command=predict).pack(pady=20)

root.mainloop()